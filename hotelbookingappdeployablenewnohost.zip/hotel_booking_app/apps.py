from django.apps import AppConfig


class HotelBookingAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hotel_booking_app'

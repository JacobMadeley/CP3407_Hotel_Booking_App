### This folder is for storing images used in this project.

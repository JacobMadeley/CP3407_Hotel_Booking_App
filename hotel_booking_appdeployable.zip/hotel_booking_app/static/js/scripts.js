/**
 * # JavaScript functions for webapp
 */
